<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,700" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
        crossorigin="anonymous">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="styles_petClinic.css">
	<title>Services</title>
</head>
<body>

	 <header class="py-5 bg-image-full" style="background-image: url('https://images.unsplash.com/photo-1549379702-9692e37d2e58?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2545&q=80');">
       <div class="col-lg-12">
          <h1 class="display-4 text-white mt-5 mb-2">Services</h1>
          <p class="lead mb-5 text-white-50">Get in touch to find out more</p>
        </div>
     </header>

	<nav id="mainNavbar" class="navbar navbar-dark navbar-expand-md py-0 fixed-top">
       <a href="#" class="navbar-brand">Noah's Pet Clinic</a>

        <button class="navbar-toggler" data-toggle="collapse" data-target="#navLinks" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navLinks">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="index.html" class="nav-link">HOME</a>
                </li>
                <li class="nav-item">
                    <a href="about.html" class="nav-link">ABOUT</a>
                </li>
 
                <li class="nav-item">
                    <a href="services02.php" class="nav-link">SERVICES</a>
                </li>
                <li class="nav-item">
                   <a href="contactus.html" class="nav-link">CONTACT US</a></li>
                <li class="nav-item">
                    <a href="register.html" class="nav-link">REGISTER</a>
                </li>
            </ul>
        </div>
 </nav>

 <div class="container">

    <div class="row">
      <div class="col-md-8 mb-5">
        <h2>What We Do</h2>
        <hr>
        <p class="lead">Our state of the art centres are purpose built to ensure we can provide the best all-round experience.
With an average of six consultation rooms per centre, three operating theatres, x-ray, ultrasound, in-house laboratory and more, we provide full care to keep pets happy and healthy throughout their life, including a full range of products and services from vaccinations and pet passports - to orthopaedic surgery and dentals.</p>
        <a class="btn btn-primary btn-lg" href="#">View all services &raquo;</a>
      </div>
      <div class="col-md-4 mb-5">
        <h2>Contact Us</h2>
        <hr>
        <address>
          <strong>Noah's Pet Care</strong>
          <br>The Lodge,
                Aintree Clinic Gate<br>
                Langmoor Lane<br>
                Edgware<br>
                L9 7LQ<br>
        </address>
        <address>
          <abbr title="Phone">P:</abbr>
          0151 525 0847
          <br>
          <abbr title="Email">E:</abbr>
          <a href="mailto:#">noahspets@npc.co.uk</a>
        </address>
      </div>
    </div>

<div class="row">
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="https://images.unsplash.com/photo-1518914781460-a3ada465edec?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60" alt="">
          <div class="card-body">
            <h4 class="card-title">Ultrasound</h4>
            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque sequi doloribus.</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">Find Out More!</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="https://images.unsplash.com/photo-1599443015574-be5fe8a05783?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60" alt="">
          <div class="card-body">
            <h4 class="card-title">Neutering your pet</h4>
            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque sequi doloribus totam ut praesentium aut.</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">Find Out More!</a>
          </div>
        </div>
      </div>
      <div class="col-md-4 mb-5">
        <div class="card h-100">
          <img class="card-img-top" src="https://www.hillspet.com/content/dam/cp-sites/hills/hills-pet/en_us/exported/cat-care/Skyword/images/vet-vaccinating-kitten-SW.jpg" alt="">
          <div class="card-body">
            <h4 class="card-title">Vaccinations</h4>
            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">Find Out More!</a>
          </div>
        </div>
      </div>
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

   <form action="services02.php" method="post" class="lead" id="serviceForm">
  <h2 class="lead" id="services"><strong><em> Please select a service to view our prices</em></strong></h2>
<select name="select" class="lead" id="service">
    <option value="Select a service...">Select a service...</option>
    <option value="Puppy Health">Puppy Health</option>
    <option value="Dog Vaccination">Dog Vaccination</option>
    <option value="Cat Vaccination">Cat Vaccination</option>
    <option value="Ultrasound">Ultrasound</option>
    <option value="Microchipping">Microchipping</option>
    <option value="Neutering">Neutering</option>
    <option value="Emergency">Emergency Visit</option>
    <option value="Pet Passport">Pet Passport</option>
    <option value="Surgery">Surgery</option>
    <option value="Pregnancy package">Pregnancy Package</option>
    </select>
    <input type="submit" class="submit" value="Submit">
  </form>
  
  <table border="0.01" class="lead" > 
    <tr>
    <td><br>
  <?php
  if (isset($_POST['select']))
  {
  $selection = $_POST['select'];

    $con = mysqli_connect("localhost", "root", "", "Services");
    if (!$con)
    {
      die ("Connection to Database Failed");
    }
    
    else 
    { 
     $sql = "SELECT price FROM npcservices WHERE Service = '$selection'";
    }
    
    $result = $con -> query($sql);
    $row = $result -> fetch_row();
    
    echo "<br><h4><strong>$selection Price: £ $row[0]</strong></h4><br/>";
  }
  
  ?>
      </td>
    </tr>
  </table>


  <!-- Footer -->
<footer id="myFooter">
    <footer class="page-footer-5 cyan lighten-5">
  
      <p class="m-0 text-center text-white">Copyright &copy; Noah's Pet Care 2020</p>

</footer>
</footer>


 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

    <script>
        $(function () {
            $(document).scroll(function () {
                var $nav = $("#mainNavbar");
                $nav.toggleClass("scrolled", $(this).scrollTop() > $nav.height());
            });
        });
    </script>

</body>
</html>